#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

using namespace std;

const int MaxPassenger = 300;

struct Arrival {
    string destination;
    int businessFare;
    int economyFare;
    int firstClassFare;
    string boardingTime;
};


const int MaxArrivals = 8;
Arrival Arrivals[MaxArrivals] = {
    {"Turkey", 18000, 12000, 22000, "11:30 PM"},
    {"New York", 20000, 15000, 25000, "12:00 AM"},
    {"Dubai", 22000, 16000, 27000, "7:40 AM"},
    {"Saudi Arabia", 21000, 14000, 26000, "8:15 AM"},
    {"London", 23000, 17000, 28000, "9:00 AM"},
    {"Paris", 25000, 18000, 30000, "2:00 PM"},
    {"Tokyo", 24000, 19000, 29000, "5:30 PM"},
    {"Sydney", 26000, 20000, 31000, "10:00 PM"}
};


struct Passenger {
    string Name;
    int TicketNo;
    string OtoD;
    string TClass;
    int Price;
    string BTime;

    void input_data(int ticketNo) {
        TicketNo = ticketNo;
        cout << "Enter Name of Passenger: ";
        cin.ignore();
        getline(cin, Name);

        int classOption, arrivalOption;
        cout << "Select Ticket Class:" << endl;
        cout << "1. Business Class" << endl;
        cout << "2. Economy Class" << endl;
        cout << "3. First Class" << endl;
        cout << "Enter your choice: ";
        cin >> classOption;

        cout << "Available Arrivals:" << endl;
        for (int i = 0; i < MaxArrivals; ++i) {
            cout << i + 1 << ". " << Arrivals[i].destination << " - ";
            if (classOption == 1) {
                cout << Arrivals[i].businessFare;
            }
            else if (classOption == 2) {
                cout << Arrivals[i].economyFare;
            }
            else if (classOption == 3) {
                cout << Arrivals[i].firstClassFare;
            }
            cout << " (" << Arrivals[i].boardingTime << ")" << endl;
        }
        cout << "Enter your choice: ";
        cin >> arrivalOption;

        if (classOption == 1) {
            TClass = "Business";
            OtoD = Arrivals[arrivalOption - 1].destination;
            Price = Arrivals[arrivalOption - 1].businessFare;
            BTime = Arrivals[arrivalOption - 1].boardingTime;
        }
        else if (classOption == 2) {
            TClass = "Economy";
            OtoD = Arrivals[arrivalOption - 1].destination;
            Price = Arrivals[arrivalOption - 1].economyFare;
            BTime = Arrivals[arrivalOption - 1].boardingTime;
        }
        else if (classOption == 3) {
            TClass = "First Class";
            OtoD = Arrivals[arrivalOption - 1].destination;
            Price = Arrivals[arrivalOption - 1].firstClassFare;
            BTime = Arrivals[arrivalOption - 1].boardingTime;
        }
        else {
            cout << "Invalid choice! Economy class is default opt..." << endl;
            TClass = "Economy";
            OtoD = Arrivals[arrivalOption - 1].destination;
            Price = Arrivals[arrivalOption - 1].economyFare;
            BTime = Arrivals[arrivalOption - 1].boardingTime;
        }
    }

    void display() const {
        cout << "TicketNo: " << TicketNo << ", Name: " << Name << ", OtoD: " << OtoD << ", TClass: " << TClass << ", Price: " << Price << ", BTime: " << BTime << endl;
    }
};

Passenger Array[MaxPassenger];
int ArraySize = 0;

void load_passengers() {
    ifstream file("passengers.txt");
    if (!file) {
        return;
    }

    while (file >> Array[ArraySize].TicketNo) {
        file.ignore();
        getline(file, Array[ArraySize].Name);
        getline(file, Array[ArraySize].OtoD);
        getline(file, Array[ArraySize].TClass);
        file >> Array[ArraySize].Price;
        file.ignore();
        getline(file, Array[ArraySize].BTime);
        ArraySize++;
    }
    file.close();
}

void save_passengers() {
    ofstream file("passengers.txt");
    for (int i = 0; i < ArraySize; ++i) {
        file << Array[i].TicketNo << endl;
        file << Array[i].Name << endl;
        file << Array[i].OtoD << endl;
        file << Array[i].TClass << endl;
        file << Array[i].Price << endl;
        file << Array[i].BTime << endl;
    }
    file.close();
}

void AddPassenger() {
    if (ArraySize >= MaxPassenger) {
        cout << "Error! limit exceed." << endl;
        return;
    }

    int ticketNo;
    if (ArraySize == 0) {
        ticketNo = 1;
    }
    else {
        ticketNo = Array[ArraySize - 1].TicketNo + 1;
    }
    Array[ArraySize].input_data(ticketNo);
    ArraySize++;
    save_passengers();
    cout << "\"" << Array[ArraySize - 1].Name << "\"" << " added successfully." << endl;
}

void SearchPassenger() {
    int TicketNo;
    cout << "Please Enter TicketNo: ";
    cin >> TicketNo;
    bool found = false;
    for (int i = 0; i < ArraySize; i++) {
        if (Array[i].TicketNo == TicketNo) {
            cout << "Passenger Found:" << endl;
            Array[i].display();
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "TicketNo " << TicketNo << " is not found in record!" << endl;
    }
}

void modify_pass() {
    if (ArraySize == 0) {
        cout << "There are no passengers in reservation!" << endl;
        return;
    }

    int searchID;
    cout << "Enter Passenger TicketNo: ";
    cin >> searchID;

    int index = -1;
    for (int i = 0; i < ArraySize; i++) {
        if (Array[i].TicketNo == searchID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        cout << "Passenger not found!" << endl;
        return;
    }

    cout << "Passenger found! Name: " << Array[index].Name << endl;

    cout << "Enter new Name for Passenger (or press Enter to keep current Name): ";
    cin.ignore();
    string newName;
    getline(cin, newName);
    if (!newName.empty()) {
        Array[index].Name = newName;
    }

    int classOption;
    cout << "Select new Ticket Class:" << endl;
    cout << "1. Business Class" << endl;
    cout << "2. Economy Class" << endl;
    cout << "3. First Class" << endl;
    cout << "Enter your choice: ";
    cin >> classOption;

    if (classOption == 1) {
        Array[index].TClass = "Business";
        Array[index].Price = Arrivals[index].businessFare;
    }
    else if (classOption == 2) {
        Array[index].TClass = "Economy";
        Array[index].Price = Arrivals[index].economyFare;
    }
    else if (classOption == 3) {
        Array[index].TClass = "First Class";
        Array[index].Price = Arrivals[index].firstClassFare;
    }
    else {
        cout << "Invalid choice! Ticket Class remains unchanged." << endl;
    }

    save_passengers();
    cout << "Record modified successfully." << endl;
}


void DeleteRecord() {
    if (ArraySize == 0) {
        cout << "There are no passengers in record!" << endl;
        return;
    }

    int searchID;
    cout << "Please Enter Passenger TicketNo to delete: ";
    cin >> searchID;

    int index = -1;
    for (int i = 0; i < ArraySize; i++) {
        if (Array[i].TicketNo == searchID) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        cout << "Passenger not found!" << endl;
        return;
    }

    for (int i = index; i < ArraySize - 1; i++) {
        Array[i] = Array[i + 1];
    }
    ArraySize--;
    save_passengers();
    cout << "Record deleted successfully." << endl;
}

void Display() {
    cout << endl;
    cout << "\t\t\t\t" << "Airline Reservation System" << endl;
    cout << endl;

    const long int First = 15;
    const long int Second = 25;
    const long int Third = 20;

    for (int i = 0; i < ArraySize - 1; i++) {
        for (int j = 0; j < ArraySize - i - 1; j++) {
            if (Array[j].Price < Array[j + 1].Price) {
                Passenger temp = Array[j];
                Array[j] = Array[j + 1];
                Array[j + 1] = temp;
            }
        }
    }

    cout << setw(Third) << left << " Name"
        << setw(First) << left << "TicketNo"
        << setw(Second) << left << "Origin To Destination"
        << setw(First) << left << "Ticket Class"
        << setw(First) << left << "Price"
        << setw(First) << left << "Boarding Time" << endl;

    cout << "==========================================================================================================" << endl;

    for (int i = 0; i < ArraySize; i++) {
        cout << setw(Third) << left << Array[i].Name
            << setw(First) << left << Array[i].TicketNo
            << setw(Second) << left << Array[i].OtoD
            << setw(First) << left << Array[i].TClass
            << setw(First) << left << Array[i].Price
            << setw(First) << left << Array[i].BTime << endl;
    }
}

int main() {
    load_passengers();
    int option;

    do {
        system("cls");

        cout << setfill('=') << setw(50) << "=" << endl;
        cout << setfill(' ') << setw(35) << left << " Airline Reservation System" << endl;
        cout << setfill('=') << setw(50) << "=" << endl;

        cout << setfill(' ') << setw(5) << " " << "Menu Options:" << endl;
        cout << setw(5) << " " << "1. Add Passenger" << endl;
        cout << setw(5) << " " << "2. Search Passenger" << endl;
        cout << setw(5) << " " << "3. Modify Passenger" << endl;
        cout << setw(5) << " " << "4. Delete Passenger" << endl;
        cout << setw(5) << " " << "5. Display Passengers" << endl;
        cout << setw(5) << " " << "6. Exit" << endl;
        cout << setfill('=') << setw(50) << "=" << endl;

        cout << setfill(' ') << setw(5) << " " << "Enter your choice: ";
        cin >> option;

        system("cls");

        switch (option) {
        case 1:
            AddPassenger();
            break;
        case 2:
            SearchPassenger();
            break;
        case 3:
            modify_pass();
            break;
        case 4:
            DeleteRecord();
            break;
        case 5:
            Display();
            break;
        case 6:
            cout << " the end" << endl;
            break;
        default:
            cout << "try again please chose from the given option." << endl;
        }

        if (option != 6) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
        }
    } while (option != 6);

    return 0;
}